const nodemailer = require('nodemailer');
const express = require('express');
const cors = require('cors')
const bodyParser = require("body-parser");
const app = express();
app.use(cors())
app.use(bodyParser.json());

app.post('/send-email', (req, res) => {
  const email = req.body?.email;
  console.log(email)
  const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false, // true for TLS, false for SSL
    auth: {
      user: 'lamitvnviec@gmail.com',
      pass: 'cwac agtv qplz umrp'
    }
  });

  // const email = req.body?.email
  // console.log(req.body)
  // console.log(req.body?.email)
  // console.log(req.payload)
  const mailOptions = {
    from: 'lamitvnviec@gmail.com',
    to: email,
    subject: 'Bạn đã trúng tuyển',
    text: 'Bạn trúng tuyển thực tập với mức lương trợ cấp 50 triệu/tháng.'
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      res.send('Error sending email: ' + error);
    } else {
        // Thực hiện hành động cần thiết
        // Ví dụ: Gửi email đến email được nhập
        console.log("Nhận được email: " + email);
        res.json("Cảm ơn bạn đã gửi email!");
    }
  });
});

app.listen(3000, () => console.log('Server started on port 3000'));
